# Aurora — Meus gastos

Controle financeiro pessoal em um único arquivo (`index.html`). Sem servidor, sem conta, sem Claude:
tudo roda no seu navegador e os dados ficam salvos **só nele** (localStorage). Nada é enviado para a internet.

## Como publicar (escolha uma opção)

**Netlify Drop (mais fácil, grátis)**
1. Acesse app.netlify.com/drop
2. Arraste a pasta `aurora` (ou só o `index.html`) para a página.
3. Pronto: você recebe um link. Abra pelo mesmo link sempre.

**GitHub Pages (grátis)**
1. Crie um repositório e envie o `index.html`.
2. Em Settings → Pages, escolha a branch `main` e a pasta raiz.

**Vercel / Cloudflare Pages**: crie um projeto novo e envie a pasta (sem build, sem comandos).

**Só no seu computador**: dê dois cliques no `index.html`. Funciona, mas os dados ficam presos àquele
arquivo/caminho; para uso diário, prefira um link publicado.

## Importante sobre os seus dados
- Os dados ficam no navegador e no endereço (domínio) em que você usa. **Outro navegador, outro aparelho ou outro
  endereço = painel vazio.** Não há sincronização automática entre aparelhos.
- Limpar os dados do navegador apaga tudo. **Use "Exportar backup" com frequência** e guarde o arquivo `.json`.
- Para restaurar ou passar os dados para outro aparelho: "Importar backup" (substitui os dados atuais).

## Trazer os dados do Aurora que estava no Claude
No painel antigo (dentro do Claude), clique em **Exportar**, salve o arquivo `.json` e, no site novo, use
**Importar backup**. O novo site aceita esse arquivo.

## Fontes
O visual usa as fontes Fraunces e DM Sans do Google Fonts. Se estiver sem internet ou quiser evitar essa
requisição, apague a linha `<link rel="stylesheet" href="https://fonts.googleapis.com/...">` do `index.html`:
o site continua funcionando com fontes do sistema (só muda levemente a tipografia).
